package main

func main() {
	var a byte = 13
}
