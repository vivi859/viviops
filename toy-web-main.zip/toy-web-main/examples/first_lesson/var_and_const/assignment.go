package main

func main() {
	 a := 13
	 println(a)
	 b := "你好"
	 println(b)
}

