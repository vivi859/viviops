package main

func main() {
	
}

// 输出两位小数
func printNumWith2(float642 float64) string {
	return ""
}

func printBytes(data []byte) string {
	return ""
}
