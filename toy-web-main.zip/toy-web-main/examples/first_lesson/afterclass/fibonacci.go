package main

func main() {

}

func fibonacci(n int) int {
	// TODO
	return 0
}
