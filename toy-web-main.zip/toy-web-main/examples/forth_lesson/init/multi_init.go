package main

func init() {
	// 第一个
}

func init() {
	// 第二个
}
