package afterclass

type Tree interface {

}

// 二叉树
type binaryTree struct {

}

// 多叉树
type mutliWayTree struct {

}
